<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Message;

class MessageController extends Controller
{
    // Menampilkan halaman indeks dengan daftar pesan
    public function index()
    {
        $messages = Message::all();
        return view('index', ['messages' => $messages]);
    }

    // Menyimpan pesan baru
    public function store(Request $request)
    {
        // Validasi input
        $request->validate([
            'name' => 'required',
            'message' => 'required',
        ]);

        // Simpan pesan baru ke database
        Message::create([
            'name' => $request->name,
            'message' => $request->message,
        ]);

        return redirect('/#rsvp')->with('success', 'Pesan berhasil dikirim!');
    }

    // Menampilkan form untuk membuat pesan baru
    public function create()
    {
        return view('messages.create');
    }

    // Menampilkan detail pesan
    public function show($id)
    {
        $message = Message::findOrFail($id);
        return view('messages.show', ['message' => $message]);
    }

    // Menampilkan form untuk mengedit pesan
    public function edit($id)
    {
        $message = Message::findOrFail($id);
        return view('messages.edit', ['message' => $message]);
    }

    // Mengupdate pesan di database
    public function update(Request $request, $id)
    {
        // Validasi input
        $request->validate([
            'name' => 'required',
            'message' => 'required',
        ]);

        // Temukan pesan yang akan diperbarui
        $message = Message::findOrFail($id);

        // Perbarui data pesan
        $message->name = $request->name;
        $message->message = $request->message;
        $message->save();

        return redirect('/messages')->with('success', 'Pesan berhasil diperbarui!');
    }

    // Menghapus pesan dari database
    public function destroy($id)
    {
        // Temukan pesan yang akan dihapus
        $message = Message::findOrFail($id);

        // Hapus pesan dari database
        $message->delete();

        return redirect('/messages')->with('success', 'Pesan berhasil dihapus!');
    }
}
