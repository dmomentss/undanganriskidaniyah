<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Attendance extends Model
{
    use HasFactory;

    protected $fillable = ['nama', 'kehadiran', 'jumlah'];

    // Mendefinisikan mutator untuk kolom "kehadiran"
    public function setKehadiranAttribute($value)
    {
        $this->attributes['kehadiran'] = strtolower($value);
    }

    // Mendefinisikan aksesors untuk kolom "kehadiran"
    public function getKehadiranAttribute($value)
    {
        return ucfirst($value);
    }
}
